// Motor WebGL para efeitos (funciona em Android e iPhone — Safari não suporta ctx.filter).
// Convenções: todas as texturas são alfa pré-multiplicado; uv (0,0) = canto superior esquerdo.

const VERT = `
attribute vec2 a_pos;
varying vec2 v_uv;
uniform float u_flip;
void main() {
  v_uv = a_pos * 0.5 + 0.5;
  vec2 p = a_pos;
  if (u_flip > 0.5) p.y = -p.y;
  gl_Position = vec4(p, 0.0, 1.0);
}`;

export const PRELUDE = `
precision highp float;
varying vec2 v_uv;
uniform sampler2D u_tex;
uniform vec2 u_size;      // tamanho da saída em px
uniform vec2 u_texel;     // 1 / tamanho da entrada
uniform vec4 u_rect;      // retângulo do conteúdo (sem padding) em uv: x, y, w, h
uniform float u_time;
uniform float u_scale;
const float PI = 3.14159265;
vec4 unpre(vec4 c) { return c.a > 0.0001 ? vec4(c.rgb / c.a, c.a) : vec4(0.0); }
vec4 pre(vec4 c) { return vec4(c.rgb * c.a, c.a); }
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float hash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float hash1(float n) { return fract(sin(n * 12.9898) * 43758.5453); }
float vnoise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}
float fbm(vec2 p, int oct) {
  float v = 0.0, a = 0.5;
  for (int i = 0; i < 6; i++) { if (i >= oct) break; v += a * vnoise(p); p *= 2.03; a *= 0.5; }
  return v;
}
vec3 rgb2hsv(vec3 c) {
  vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
  vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
  vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
  float d = q.x - min(q.w, q.y);
  return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + 1e-10)), d / (q.x + 1e-10), q.x);
}
vec3 hsv2rgb(vec3 c) {
  vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
  return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}
vec4 samp(vec2 uv) { return (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) ? vec4(0.0) : texture2D(u_tex, uv); }
vec2 contentUV(vec2 uv) { return (uv - u_rect.xy) / u_rect.zw; }      // 0..1 dentro do conteúdo
vec2 fromContent(vec2 c) { return u_rect.xy + c * u_rect.zw; }
`;

const COPY = `${PRELUDE}
uniform float u_alpha;
void main() { gl_FragColor = texture2D(u_tex, v_uv) * u_alpha; }`;

const BLUR = `${PRELUDE}
uniform vec2 u_dir;     // direção em texels
uniform float u_sigma;  // em texels
void main() {
  vec4 acc = vec4(0.0);
  float wsum = 0.0;
  float step = max(1.0, u_sigma * 3.0 / 12.0);
  for (int i = -12; i <= 12; i++) {
    float x = float(i) * step;
    float w = exp(-(x * x) / (2.0 * u_sigma * u_sigma + 1e-5));
    acc += samp(v_uv + u_dir * u_texel * x) * w;
    wsum += w;
  }
  gl_FragColor = acc / wsum;
}`;

const ADD = `${PRELUDE}
uniform sampler2D u_tex2;
uniform float u_amount;
void main() { gl_FragColor = min(texture2D(u_tex, v_uv) + texture2D(u_tex2, v_uv) * u_amount, vec4(1.0)); }`;

const MIX = `${PRELUDE}
uniform sampler2D u_tex2;
uniform float u_amount;
void main() { gl_FragColor = mix(texture2D(u_tex, v_uv), texture2D(u_tex2, v_uv), u_amount); }`;

export class GLEngine {
  constructor() {
    this.canvas = typeof document !== 'undefined' ? document.createElement('canvas') : new OffscreenCanvas(16, 16); // Worker: OffscreenCanvas
    this.canvas.width = this.canvas.height = 16;
    const opts = { premultipliedAlpha: true, preserveDrawingBuffer: true, alpha: true, antialias: false };
    this.gl = this.canvas.getContext('webgl', opts) || this.canvas.getContext('experimental-webgl', opts);
    if (!this.gl) throw new Error('WebGL indisponível');
    const gl = this.gl;
    this.maxSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
    this.programs = new Map();
    this.pool = [];
    this.live = [];
    const buf = gl.createBuffer();
    this.quad = buf;
    this.meshes = new Map();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    this.htype = this.detectHalfFloat();
    gl.disable(gl.BLEND);
    gl.disable(gl.DEPTH_TEST);
    this.env = {};
  }

  program(frag) {
    let p = this.programs.get(frag);
    if (p) return p;
    const gl = this.gl;
    const compile = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(`Shader: ${gl.getShaderInfoLog(s)}`);
      return s;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, VERT));
    // com texturas de 16 bits o resultado de cada passada não é mais cortado em 0..1 automaticamente:
    // o main() original vira mf_main() e o novo main() corta no fim (mesmo visual do 8 bits, sem perder precisão)
    const src = this.htype && !frag.startsWith('// @noclamp') && /void\s+main\s*\(\s*\)/.test(frag)
      ? `${frag.replace(/void\s+main\s*\(\s*\)/, 'void mf_main()')}\nvoid main() { mf_main(); gl_FragColor = clamp(gl_FragColor, 0.0, 1.0); }`
      : frag;
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, src));
    gl.bindAttribLocation(prog, 0, 'a_pos');
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(`Link: ${gl.getProgramInfoLog(prog)}`);
    p = { prog, locs: new Map() };
    this.programs.set(frag, p);
    return p;
  }

  loc(p, name) {
    if (!p.locs.has(name)) p.locs.set(name, this.gl.getUniformLocation(p.prog, name));
    return p.locs.get(name);
  }

  /**
   * Texturas intermediárias em 16 bits (half-float) quando o aparelho suporta renderizar e filtrar nelas:
   * efeitos empilhados (glow, blur, CC, grão…) não perdem precisão a cada passada → sem faixas nos degradês.
   */
  detectHalfFloat() {
    const gl = this.gl;
    try {
      const hf = gl.getExtension('OES_texture_half_float');
      const lin = gl.getExtension('OES_texture_half_float_linear');
      gl.getExtension('EXT_color_buffer_half_float');
      if (!hf || !lin) return 0;
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 4, 4, 0, gl.RGBA, hf.HALF_FLOAT_OES, null);
      const fbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
      const ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.deleteFramebuffer(fbo); gl.deleteTexture(tex);
      return ok ? hf.HALF_FLOAT_OES : 0;
    } catch { return 0; }
  }

  acquire(w, h, u8 = false) {
    w = Math.max(1, Math.min(this.maxSize, Math.round(w)));
    h = Math.max(1, Math.min(this.maxSize, Math.round(h)));
    u8 = u8 || !this.htype;
    const i = this.pool.findIndex((t) => t.w === w && t.h === h && t.u8 === u8);
    let t;
    if (i >= 0) t = this.pool.splice(i, 1)[0];
    else {
      const gl = this.gl;
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, u8 ? gl.UNSIGNED_BYTE : this.htype, null);
      this.texParams();
      const fbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
      t = { tex, fbo, w, h, u8 };
    }
    this.live.push(t);
    return t;
  }

  texParams() {
    const gl = this.gl;
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  }

  /** Libera todas as texturas usadas desde o último releaseAll (fim de cada camada). */
  /** Devolve uma textura ao pool antes do fim da camada (efeitos pesados: menos memória de vídeo ao mesmo tempo). */
  release(t) {
    if (!t) return;
    const i = this.live.indexOf(t);
    if (i >= 0) { this.live.splice(i, 1); this.pool.push(t); }
  }

  releaseAll() {
    this.pool.push(...this.live);
    this.live = [];
  }

  /**
   * Limite de memória das texturas livres (por bytes, não por quantidade): em 16 bits cada textura 1080×1920
   * ocupa ~17 MB e as 4K ~66 MB — 40 delas passavam de 1 GB. Libera as mais antigas além do limite.
   */
  trimPool() {
    const budget = this.poolBudget || (this.poolBudget = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.maxTouchPoints > 1 && /Macintosh/.test(navigator.userAgent)) ? 160e6 : 320e6); // texturas livres guardadas para reaproveitar (acima disso a memória de vídeo enchia em sessões longas)
    const bytes = (t) => t.w * t.h * (t.u8 ? 4 : 8);
    let total = this.pool.reduce((s, t) => s + bytes(t), 0);
    if (total <= budget && this.pool.length <= 96) return;
    const gl = this.gl;
    while (this.pool.length && (total > budget * 0.75 || this.pool.length > 96)) {
      const t = this.pool.shift();
      total -= bytes(t);
      gl.deleteTexture(t.tex); gl.deleteFramebuffer(t.fbo);
    }
  }

  upload(source, w = source.width, h = source.height) {
    const gl = this.gl;
    const t = this.acquire(w, h, true); // imagens/vídeos entram em 8 bits (é o que o navegador entrega)
    gl.bindTexture(gl.TEXTURE_2D, t.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    return t;
  }

  /** Executa um fragment shader. inputs: { u_tex: target, u_tex2: target, u_x: number|array }. */
  pass(frag, inputs = {}, w, h, out) {
    const gl = this.gl;
    const src = inputs.u_tex;
    w = w ?? src.w; h = h ?? src.h;
    const target = out === 'screen' ? null : out || this.acquire(w, h);
    const p = this.program(frag);
    gl.useProgram(p.prog);
    if (target) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fbo);
      gl.viewport(0, 0, target.w, target.h);
    } else {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      if (this.canvas.width < w || this.canvas.height < h) {
        this.canvas.width = Math.max(this.canvas.width, Math.ceil(w));
        this.canvas.height = Math.max(this.canvas.height, Math.ceil(h));
      }
      gl.viewport(0, this.canvas.height - h, w, h);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
    let unit = 0;
    const env = { u_size: [w, h], u_time: 0, u_scale: 1, u_rect: [0, 0, 1, 1], ...this.env, u_flip: target ? 0 : 1 };
    const all = { ...env, ...inputs };
    if (src) all.u_texel = [1 / src.w, 1 / src.h];
    for (const [name, v] of Object.entries(all)) {
      const l = this.loc(p, name);
      if (l === null) continue;
      if (v && v.tex) {
        gl.activeTexture(gl.TEXTURE0 + unit);
        gl.bindTexture(gl.TEXTURE_2D, v.tex);
        gl.uniform1i(l, unit++);
      } else if (v && v.vec3) gl.uniform3fv(l, v.vec3); // vetor de vec3 (ex.: uniform vec3 u_hsl[8])
      else if (v && v.vec2) gl.uniform2fv(l, v.vec2);
      else if (v && v.f1) gl.uniform1fv(l, v.f1);
      else if (typeof v === 'number' || typeof v === 'boolean') gl.uniform1f(l, +v);
      else if (Array.isArray(v)) {
        if (v.length === 2) gl.uniform2fv(l, v);
        else if (v.length === 3) gl.uniform3fv(l, v);
        else if (v.length === 4) gl.uniform4fv(l, v);
      }
    }
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    return target;
  }

  /**
   * Desenha geometria (triângulos) num alvo novo — usado por efeitos 3D como o Shatter.
   * build() → { data: Float32Array, attribs: [[nome, tamanho], …] } (intercalado); fica em cache por `key`.
   */
  mesh(key, build, vert, frag, uniforms, w, h, opts = {}) {
    const gl = this.gl;
    let m = this.meshes.get(key);
    if (!m) {
      const g = build();
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, g.data, gl.STATIC_DRAW);
      const stride = g.attribs.reduce((n, [, s]) => n + s, 0);
      m = { buf, attribs: g.attribs, stride, count: g.data.length / stride };
      if (this.meshes.size > 6) { const [k0, old] = this.meshes.entries().next().value; gl.deleteBuffer(old.buf); this.meshes.delete(k0); }
      this.meshes.set(key, m);
    }
    const pkey = vert + frag;
    let p = this.programs.get(pkey);
    if (!p) {
      const compile = (type, src) => {
        const s = gl.createShader(type);
        gl.shaderSource(s, src);
        gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(`Shader: ${gl.getShaderInfoLog(s)}`);
        return s;
      };
      const prog = gl.createProgram();
      gl.attachShader(prog, compile(gl.VERTEX_SHADER, vert));
      gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, frag));
      m.attribs.forEach(([name], i) => gl.bindAttribLocation(prog, i, name));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(`Link: ${gl.getProgramInfoLog(prog)}`);
      p = { prog, locs: new Map() };
      this.programs.set(pkey, p);
    }
    const target = this.acquire(w, h);
    gl.useProgram(p.prog);
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fbo);
    gl.viewport(0, 0, target.w, target.h);
    gl.clearColor(0, 0, 0, 0);
    // profundidade (cacos 3D com espessura): renderbuffer de profundidade reaproveitado por tamanho
    let depthRb = null;
    if (opts.depth) {
      const k = `${target.w}x${target.h}`;
      if (!this.depthRbs) this.depthRbs = new Map();
      depthRb = this.depthRbs.get(k);
      if (!depthRb) {
        depthRb = gl.createRenderbuffer();
        gl.bindRenderbuffer(gl.RENDERBUFFER, depthRb);
        gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, target.w, target.h);
        if (this.depthRbs.size > 3) { const [k0, old] = this.depthRbs.entries().next().value; gl.deleteRenderbuffer(old); this.depthRbs.delete(k0); }
        this.depthRbs.set(k, depthRb);
      }
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depthRb);
      gl.clearDepth(1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);
      gl.depthFunc(gl.LEQUAL);
    } else gl.clear(gl.COLOR_BUFFER_BIT);
    let unit = 0;
    for (const [name, v] of Object.entries({ ...this.env, ...uniforms })) {
      const l = this.loc(p, name);
      if (l === null) continue;
      if (v && v.tex) { gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, v.tex); gl.uniform1i(l, unit++); }
      else if (v && v.f1) gl.uniform1fv(l, v.f1);
      else if (typeof v === 'number' || typeof v === 'boolean') gl.uniform1f(l, +v);
      else if (Array.isArray(v)) [null, null, gl.uniform2fv, gl.uniform3fv, gl.uniform4fv][v.length]?.call(gl, l, v);
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, m.buf);
    let off = 0;
    m.attribs.forEach(([, size], i) => {
      gl.enableVertexAttribArray(i);
      gl.vertexAttribPointer(i, size, gl.FLOAT, false, m.stride * 4, off * 4);
      off += size;
    });
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.drawArrays(gl.TRIANGLES, 0, m.count);
    gl.disable(gl.BLEND);
    if (depthRb) { gl.disable(gl.DEPTH_TEST); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, null); }
    for (let i = 1; i < m.attribs.length; i++) gl.disableVertexAttribArray(i);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    return target;
  }

  /**
   * Desenha a textura num quadrilátero em perspectiva (camada 3D vista pela câmera). verts = 4 cantos em
   * coordenadas de recorte (x, y, z, w) na ordem do contorno; uvs = coordenadas de textura de cada canto.
   */
  quad3d(src, verts, uvs, w, h) {
    const gl = this.gl;
    if (!this.q3) {
      const vs = 'attribute vec4 a_clip; attribute vec2 a_uv; varying vec2 v_uv; void main() { v_uv = a_uv; gl_Position = a_clip; }';
      const fs = 'precision highp float; uniform sampler2D u_tex; varying vec2 v_uv; void main() { gl_FragColor = texture2D(u_tex, v_uv); }';
      const sh = (type, src0) => { const x = gl.createShader(type); gl.shaderSource(x, src0); gl.compileShader(x); return x; };
      const prog = gl.createProgram();
      gl.attachShader(prog, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, fs));
      gl.bindAttribLocation(prog, 0, 'a_clip'); gl.bindAttribLocation(prog, 1, 'a_uv');
      gl.linkProgram(prog);
      this.q3 = { prog, buf: gl.createBuffer(), loc: gl.getUniformLocation(prog, 'u_tex') };
    }
    const order = [0, 1, 2, 0, 2, 3];
    const data = new Float32Array(order.flatMap((i) => [...verts[i], ...uvs[i]]));
    const target = this.acquire(w, h);
    gl.useProgram(this.q3.prog);
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fbo);
    gl.viewport(0, 0, target.w, target.h);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, src.tex); gl.uniform1i(this.q3.loc, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.q3.buf);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 24, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 24, 16);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.disableVertexAttribArray(1);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    return target;
  }

  copy(src, w, h, alpha = 1) { return this.pass(COPY, { u_tex: src, u_alpha: alpha }, w, h); }

  /** Desfoque gaussiano separável (sigma em px). dims: 1 ambos, 2 horizontal, 3 vertical. */
  blur(src, sigma, dims = 1, low = false, pyr = null) {
    if (sigma < 0.3) return src;
    // reduz em etapas de 2× (filtro passa-baixa correto), desfoca na escala reduzida e amplia em etapas
    let f = 1;
    while (sigma / f > 8 && f < 16) f *= 2;
    // pyr: vários desfoques da MESMA textura reaproveitam as reduções já feitas (resultado idêntico)
    const chain = pyr || [src];
    if (chain[0] !== src) { chain.length = 0; chain.push(src); }
    let t = src;
    for (let k = 2, i = 1; k <= f; k *= 2, i++) {
      if (!chain[i]) chain[i] = this.copy(t, Math.max(1, Math.round(src.w / k)), Math.max(1, Math.round(src.h / k)));
      t = chain[i];
    }
    const top = Math.log2(f) | 0;
    const s = sigma / f;
    if (dims !== 3) t = this.pass(BLUR, { u_tex: t, u_dir: [1, 0], u_sigma: s });
    if (dims !== 2) t = this.pass(BLUR, { u_tex: t, u_dir: [0, 1], u_sigma: s });
    // low: devolve na metade da resolução (sem a última ampliação 2×). Quem lê a textura por coordenada normalizada
    // (v_uv) com filtro bilinear recebe o mesmo valor da ampliação bilinear — e a passada mais cara (tela cheia) some.
    for (let i = top - 1; i >= (low ? 1 : 0); i--) {
      t = this.copy(t, chain[i].w, chain[i].h);
      if (i > 0) {
        // suaviza as etapas intermediárias (a última ampliação 2× bilinear já fica suave)
        if (dims !== 3) t = this.pass(BLUR, { u_tex: t, u_dir: [1, 0], u_sigma: 1.2 });
        if (dims !== 2) t = this.pass(BLUR, { u_tex: t, u_dir: [0, 1], u_sigma: 1.2 });
      }
    }
    return t;
  }

  /**
   * Soma de vários desfoques do mesmo src (Σ wᵢ·blur(src, σᵢ)) — mesmo resultado que chamar blur() várias vezes,
   * mas a pirâmide reduzida é feita uma vez só e a soma é ampliada uma vez só (Deep Glow: 6 desfoques → ~3× mais rápido).
   */
  blurSum(src, items) {
    // desfoques acima de 4 px já vão para a metade da resolução (antes 8 px): ~1,4× mais rápido, diferença ≤ 2–5/255
    const lv = (sg) => { let k = 0; while (sg / (1 << k) > 4 && k < 4) k++; return k; };
    const plan = items.map(({ sigma, w }) => ({ sigma, w, k: sigma < 0.3 ? -1 : lv(sigma) }));
    const K = Math.max(0, ...plan.map((q) => q.k));
    const chain = [src];
    for (let k = 1; k <= K; k++) chain.push(this.copy(chain[k - 1], Math.max(1, Math.round(src.w / (1 << k))), Math.max(1, Math.round(src.h / (1 << k)))));
    // cada textura intermediária volta ao pool assim que foi usada (pico de memória de vídeo ~3× menor)
    const rel = (t) => { if (t && !chain.includes(t)) this.release(t); };
    let acc = null;
    const addW = (t, w) => {
      const prev = acc;
      acc = prev ? this.add(prev, t, w) : (w === 1 ? t : this.add(t, t, w - 1));
      if (prev) rel(prev);
      if (acc !== t) rel(t);
    };
    for (let k = K; k >= 0; k--) {
      if (acc && k < K) {
        let up = this.copy(acc, chain[k].w, chain[k].h); rel(acc);
        if (k > 0) { const h1 = this.pass(BLUR, { u_tex: up, u_dir: [1, 0], u_sigma: 1.2 }); rel(up); up = this.pass(BLUR, { u_tex: h1, u_dir: [0, 1], u_sigma: 1.2 }); rel(h1); }
        acc = up;
      }
      for (const q of plan) {
        if (q.k !== k && !(k === 0 && q.k === -1)) continue;
        let t = chain[k];
        if (q.k >= 0) { const sg = q.sigma / (1 << k); const h1 = this.pass(BLUR, { u_tex: t, u_dir: [1, 0], u_sigma: sg }); t = this.pass(BLUR, { u_tex: h1, u_dir: [0, 1], u_sigma: sg }); rel(h1); }
        addW(t, q.w);
      }
      if (k > 0) this.release(chain[k]); // nível da pirâmide já usado
    }
    return acc;
  }

  add(a, b, amount = 1) { return this.pass(ADD, { u_tex: a, u_tex2: b, u_amount: amount }); }
  mix(a, b, amount) { return this.pass(MIX, { u_tex: a, u_tex2: b, u_amount: amount }); }

  /** Desenha a textura no canvas WebGL e devolve [canvas, w, h] para drawImage imediato. */
  toCanvas(t) {
    this.pass(COPY, { u_tex: t, u_alpha: 1 }, t.w, t.h, 'screen');
    return this.canvas;
  }
}

let engine = null;
let failed = false;
let lostListener = () => {};
/** Avisa quando a GPU derrubou o contexto (o app recria e redesenha). */
export function setGLLostListener(fn) { lostListener = fn; }
export function getGL() {
  // o iPhone/Android derrubam o contexto WebGL quando um quadro pesa demais na GPU: antes disso deixava tudo preto
  // (inclusive a exportação). Agora o motor é recriado automaticamente.
  if (engine && engine.gl.isContextLost()) { engine = null; failed = false; lostListener(); }
  if (engine || failed) return engine;
  try {
    engine = new GLEngine();
    engine.canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); engine = null; lostListener(); }, { once: true });
  } catch (e) { failed = true; console.warn('WebGL indisponível — efeitos desativados', e); }
  return engine;
}
export function glLost() { return !!engine && engine.gl.isContextLost(); }
